# COMP61332 Coursework

## Use of Generative AI Tools

Generative AI tools like ChatGPT and Claude were used for debugging relation extraction (RE) models and identifying Python functions within specific modules.

---

# NERBERT & DepPath-SVM: Relation Extraction Models

This repository contains three models:

- **NERBERT**: A BERT-based Named Entity Recognition (NER) model trained from scratch.
- **NERBERT_Pretrained**: A fine-tuned NER model using a pre-trained BERT variant.
- **DepPath-SVM**: A Support Vector Machine (SVM) model for relation extraction using dependency paths.

All models leverage NLP techniques for entity recognition and relation classification.

---

## Pre-Trained Models

The pre-trained models can be found in this google drive link:
https://drive.google.com/drive/folders/13kKvtrLdoR55t_MmAcPzH3SexbyZawOM?usp=sharing

## DepPath-SVM: Dependency Path-Based SVM for Relation Extraction

### Overview

DepPath-SVM is an ensemble-based SVM model designed for relation extraction. It classifies relationships between entities using dependency paths and is trained on the WebNLG dataset.

### Dataset Setup

Clone the WebNLG dataset and toolkit:

```bash
git clone https://gitlab.com/shimorina/webnlg-dataset.git
git clone https://github.com/WebNLG/webnlg_toolkit.git
cd webnlg_toolkit
pip install -e .
```

### Preprocessing

The preprocessing pipeline:

1. Extracts sentences, entities, and relations from the WebNLG dataset.
2. Uses **spaCy** to generate dependency paths.
3. Converts data into feature vectors using `TfidfVectorizer` (text) and `CountVectorizer` (dependency paths).

### Model Architecture

The model is an ensemble of three SVM classifiers with different kernels:

- **Linear SVM**: Captures spatial relationships.
- **RBF SVM**: Identifies temporal dependencies.
- **Polynomial SVM**: Detects causal connections.

The ensemble uses a **Voting Classifier** to combine predictions.

### Training

```python
svm_pipeline.fit(X_train, y_train)
```

### Model Saving & Loading

Save the trained model:

```python
import pickle
with open('svm_model.pkl', 'wb') as f:
    pickle.dump(svm_pipeline, f)
```

Load the model for inference:

```python
with open('svm_model.pkl', 'rb') as f:
    svm_pipeline = pickle.load(f)
```

### Evaluation

```python
from sklearn.metrics import classification_report, f1_score

svm_preds = svm_pipeline.predict(X_test)
svm_accuracy = (svm_preds == y_test).mean()
svm_f1 = f1_score(y_test, svm_preds, average='weighted')

print(classification_report(y_test, svm_preds))
```

### Real-Time Inference

```python
def extract_relation(entity1, entity2):
    text = f"{entity1} {entity2}"
    return svm_pipeline.predict([text])
```

Example:

```python
entity1, entity2 = "Georgia (US State)", "United States"
print(f"Extracted relation: {extract_relation(entity1, entity2)}")
```

---

## NERBERT: Named Entity Recognition using BERT

### Overview

NERBERT is a transformer-based model for Named Entity Recognition (NER). It classifies words into predefined entity categories using contextual embeddings from **BERT**.

### Requirements

Install dependencies:

```bash
pip install transformers datasets torch scikit-learn
```

### Usage

The notebook covers:

- Tokenization with **BERT tokenizer**.
- Model fine-tuning on an NER dataset.
- Entity classification using **pretrained BERT embeddings**.
- Performance evaluation with **precision, recall, and F1-score**.

### Results

The trained model provides entity recognition outputs, evaluated using:

```python
from sklearn.metrics import classification_report

y_preds = model.predict(X_test)
print(classification_report(y_test, y_preds))
```

---

## NERBERT_Pretrained: Testing the Model

### Overview

NERBERT_Pretrained is a using the pretrained model saved from training the NER-BERT model in the NERBERT.ipynb notebook to test it on the test dataset.

### Requirements

Same as NERBERT:

```bash
pip install transformers datasets torch scikit-learn
```

### Process

1. Loads a **pre-trained BERT model** from Hugging Face.
2. Fine-tunes it on a the dataset.
3. Uses **AdamW optimizer** and **cross-entropy loss** for training.

### Model Saving & Loading

Save the model:

```python
model.save_pretrained("ner_bert_finetuned")
```

Load the model for inference:

```python
from transformers import AutoModelForTokenClassification

model = AutoModelForTokenClassification.from_pretrained("ner_bert_finetuned")
```

### Inference Example

```python
from transformers import AutoTokenizer

tokenizer = AutoTokenizer.from_pretrained("bert-base-cased")

def predict_entities(text):
    inputs = tokenizer(text, return_tensors="pt")
    outputs = model(**inputs)
    return outputs

text = "Barack Obama was born in Hawaii."
entities = predict_entities(text)
print(entities)
```

---

## Installation

Install all dependencies:

```bash
pip install -r requirements.txt
```

---

## Authors

Suha Shafi, Sameep Singh, Vismaya Venkateshwara
